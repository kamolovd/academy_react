import { useSelector } from 'react-redux';
import { NavLink } from 'react-router-dom';
import styles from './Navbar.module.css';

const navLinks = [
    {
        path: '/',
        label: 'Home'
    },
    {
        path: '/users',
        label: 'Users'
    },
    {
        path: '/about',
        label: 'About'
    },
    {
        path: '/categories',
        label: 'Categories'
    },
    {
        path: '/products',
        label: 'Products'
    },
    {
        path: '/cart',
        label: 'Cart'
    },
];

const Navbar = () => {
    const counterUserCart = useSelector((state) => state.users.selectUsersToCart).length;

    console.log(counterUserCart)
    return (
        <div className={styles.container}>
            {navLinks.map((item, idx) =>
                <NavLink className={({isActive}) => isActive ? `${styles.nav_item} ${styles.nav_item_active}` : `${styles.nav_item}`} key={idx} to={item.path}>
                    {item.label}
                </NavLink>
            )}
            <div className={styles.count}>Count: {counterUserCart}</div>
        </div>
    )
}

export default Navbar;