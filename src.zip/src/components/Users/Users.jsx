import { useState } from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getUsers, setSelectUsersToCart } from "../../store/features/users/usersSlice";
import styles from './Users.module.css'

const Users = () => {
    const usersList = useSelector((state) => state.users.usersList);
    const selectUsersToCart = useSelector((state) => state.users.selectUsersToCart);
    const loading = useSelector((state) => state.users.loading);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleSetUser = (user) => {
        let haveUser = selectUsersToCart.filter((item) => item.id === user.id);
        if (haveUser.length === 0) {
            dispatch(setSelectUsersToCart(user))
        }
    }

    useEffect(() => {
        dispatch(getUsers())
    }, [])

   
    return (
        <>
            {loading ? <h3 style={{textAlign: 'center'}}>Loading...</h3> : 
            <div className={styles.users_list}>
                {usersList.map((user) => 
                    <div onClick={() => {
                        navigate(`/user/${user.id}`)
                        // handleSetUser(user)
                        }} className={styles.user_card} key={user.id}>
                        <div className={styles.first_name}>{user.first_name}</div>
                        <div className={styles.last_name}>{user.last_name}</div>
                    </div>                
                )}
            </div>
            }
        </>
    )
}

export default Users;