import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { getUserById, setSelectUser } from "../../store/features/users/usersSlice";
import styles from './UserById.module.css';

const UserById = () => {
    const { userId } = useParams();
    const dispatch = useDispatch();
    const selectUser = useSelector((state) => state.users.selectUser);
    const loading = useSelector((state) => state.users.loading);


    useEffect(() => {
        if (userId) {
            dispatch(getUserById(userId))
        }

        return () => {
            dispatch(setSelectUser(null))
        }
    }, [userId])
    

    return (
        <div>
            {loading ? <h3 style={{ textAlign: 'center' }}>Loading...</h3> :
                <>
                    {selectUser ?
                        <div style={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', alignItems: 'center' }}>
                            <img src={selectUser.avatar} width={100} />
                            <h3 className={styles.first_name}>{selectUser.first_name}</h3>
                            <h3 className={styles.last_name}>{selectUser.last_name}</h3>
                            <h3 className={styles.last_name}>{selectUser.email}</h3>
                        </div>
                        : <div>Not Found</div>
                    }
                </>
            }
        </div>
    )
}

export default UserById;