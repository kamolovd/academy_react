import { useDispatch, useSelector } from "react-redux";
import { deleteUsersToCart } from "../../store/features/users/usersSlice";
import styles from './Cart.module.css';

const Cart = () => {
    const usersList = useSelector((state) => state.users.selectUsersToCart);
    const dispatch = useDispatch();
    const selectUsers = JSON.parse(localStorage.getItem('selectUsers'));

    return (
        <div className={styles.users_list}>
            {usersList.map((item) => 
                <div className={styles.user_card} key={item.id}>
                    <div className={styles.first_name}>{item.first_name}</div>
                    <div className={styles.first_name}>{item.last_name}</div>
                    <button onClick={() => dispatch(deleteUsersToCart(item))}>Delete</button>
                </div>
            )}
           
        </div>
    )
}

export default Cart;