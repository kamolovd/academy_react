

function Categories() {
    return (
        <div>
            Categories
        </div>
    )
}

export default Categories;