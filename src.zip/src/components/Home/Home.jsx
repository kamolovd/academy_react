import { useState } from "react";


function Home() {
    const [age, setAge] = useState('');

    return (
        <>
            <div>
                Home
            </div>
            <input value={age} type="number" onChange={e => setAge(e.target.value)} placeholder='Имя пользователя'/>
            <button onClick={() => localStorage.setItem('age', age)}>Save to Local Storage</button>
        </>
    )
}

export default Home;