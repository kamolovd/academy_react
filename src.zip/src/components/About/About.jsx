function About() {
    return (
        <div>
            About
            <h3>
                {localStorage.getItem('name')}
            </h3>
        </div>
    )
}

export default About;