import { Route, Routes } from 'react-router-dom';
import './App.css';
import About from './components/About/About';
import Cart from './components/Cart/Cart';
import Categories from './components/Categories/Categories';
import Home from './components/Home/Home';
import Navbar from './components/Navbar/Navbar';
import Products from './components/Products/Products';
import UserById from './components/UserById/UserById';
import Users from './components/Users/Users';





function App() {
  
  return (
    <>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/about' element={<About/>} />
        <Route path='/categories' element={<Categories/>} />
        <Route path='/products' element={<Products/>} />
        <Route path='/users' element={<Users/>} />
        <Route path='/user/:userId' element={<UserById/>}/>
        <Route path='/cart' element={<Cart/>}/>
        <Route path='*' element={<>Not Found</>} />
      </Routes>
    </>
  )
}

export default App;

